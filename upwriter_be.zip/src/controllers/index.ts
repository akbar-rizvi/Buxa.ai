import user from './user';
import document from './document';
import PaymentController  from './payment';

export default {
    user , 
    document,
    PaymentController
}