import user from "./user";
import document from "./docs";
import { Payment } from "./payment";

export default{
   user,
   document ,
   Payment
}