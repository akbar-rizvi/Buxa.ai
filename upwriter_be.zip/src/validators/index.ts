import auth from "./validators";

export default{
    auth
}